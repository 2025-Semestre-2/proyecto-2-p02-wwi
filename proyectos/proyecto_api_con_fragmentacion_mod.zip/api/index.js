const app = require('./src/app');

// El servidor se inicia en app.js
